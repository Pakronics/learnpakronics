#include "Arduino.h"

class MyClass {
// initialization
private:
void myMethod();
};

 