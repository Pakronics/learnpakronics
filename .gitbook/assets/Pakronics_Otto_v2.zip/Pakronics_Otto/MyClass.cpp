#include "Arduino.h"
#include "MyClass.h"

MyClass MyClass;

void  MyClass::myMethod() {
//dummy return
return ;
}
 